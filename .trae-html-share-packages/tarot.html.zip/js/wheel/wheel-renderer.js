// 月影决策屋 - Canvas 转盘渲染引擎

export class WheelRenderer {
    constructor(canvas, options, weights = null) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.options = options;
        this.weights = this._normalizeWeights(weights || options.map(() => 1), options.length);
        this.rotation = 0;
        this.isSpinning = false;
        this.onResult = null;
        
        this.colors = [
            '#2d1b4e','#4a2d7a','#6b3fa0','#8b5cf6',
            '#1a0e2e','#3b1f6e','#5b3fb0','#7b4fd6',
            '#3d2b5e','#5a3d8a','#7b5fb0','#9b6fe6'
        ];
        
        this.resize();
        // 3.2: 指针静态缓存（不随旋转变化）
        this._pointerCanvas = null;
        this._buildPointerCache();
        this.draw();
    }

    resize() {
        const size = Math.min(this.canvas.parentElement.clientWidth - 40, 400);
        this.canvas.width = size;
        this.canvas.height = size;
        this.centerX = size / 2;
        this.centerY = size / 2;
        this.radius = size / 2 - 20;
        this._buildPointerCache();
    }

    // 3.2: 将指针绘制到离屏 canvas，每帧直接 drawImage
    _normalizeWeights(weights, count) {
        const minWeight = 1;
        const maxWeight = 100;
        
        return weights.map(w => {
            let weight = w;
            if (isNaN(weight) || !isFinite(weight) || weight <= 0) {
                weight = 1;
            }
            weight = Math.min(Math.max(weight, minWeight), maxWeight);
            return Math.round(weight);
        });
    }

    _truncateText(text, maxLength = 8) {
        if (!text) return '';
        if (text.length <= maxLength) return text;
        return text.slice(0, maxLength) + '...';
    }

    _buildPointerCache() {
        const w = this.canvas.width;
        const h = this.canvas.height;
        this._pointerCanvas = document.createElement('canvas');
        this._pointerCanvas.width = w;
        this._pointerCanvas.height = h;
        const pCtx = this._pointerCanvas.getContext('2d');
        const centerX = w / 2;
        const pointerY = 15;

        pCtx.beginPath();
        pCtx.moveTo(centerX, pointerY);
        pCtx.lineTo(centerX - 12, pointerY - 20);
        pCtx.lineTo(centerX + 12, pointerY - 20);
        pCtx.closePath();

        const gradient = pCtx.createLinearGradient(centerX, pointerY - 20, centerX, pointerY);
        gradient.addColorStop(0, '#ffd700');
        gradient.addColorStop(1, '#b8860b');
        pCtx.fillStyle = gradient;
        pCtx.fill();
        pCtx.strokeStyle = '#ffd700';
        pCtx.lineWidth = 1;
        pCtx.stroke();
    }

    draw() {
        const { ctx, centerX, centerY, radius, options, weights } = this;
        if (options.length === 0) return;

        const totalWeight = weights.reduce((a, b) => a + b, 0);
        ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // 外圈光晕
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius + 10, 0, 2 * Math.PI);
        ctx.strokeStyle = 'rgba(212,168,67,0.3)';
        ctx.lineWidth = 3;
        ctx.stroke();

        // 绘制扇形（支持权重）
        let currentAngle = this.rotation;
        options.forEach((option, i) => {
            const sliceAngle = (weights[i] / totalWeight) * 2 * Math.PI;
            const startAngle = currentAngle;
            const endAngle = currentAngle + sliceAngle;

            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.arc(centerX, centerY, radius, startAngle, endAngle);
            ctx.fillStyle = this.colors[i % this.colors.length];
            ctx.fill();
            ctx.strokeStyle = 'rgba(212,168,67,0.5)';
            ctx.lineWidth = 1.5;
            ctx.stroke();

            // 文字
            ctx.save();
            ctx.translate(centerX, centerY);
            ctx.rotate(startAngle + sliceAngle / 2);
            ctx.fillStyle = '#f5f0ff';
            ctx.font = `${Math.max(10, 14 - options.length / 2)}px "Noto Serif SC"`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const textRadius = radius * 0.65;
            const truncatedText = this._truncateText(option, Math.max(4, 8 - options.length));
            ctx.fillText(truncatedText, textRadius, 0);
            ctx.restore();

            currentAngle = endAngle;
        });

        // 中心圆
        ctx.beginPath();
        ctx.arc(centerX, centerY, 30, 0, 2 * Math.PI);
        const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, 30);
        gradient.addColorStop(0, '#f0d68a');
        gradient.addColorStop(1, '#b8860b');
        ctx.fillStyle = gradient;
        ctx.fill();
        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#0a0612';
        ctx.font = 'bold 14px "Noto Serif SC"';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('转', centerX, centerY);

        this.drawPointer();
    }

    drawPointer() {
        // 3.2: 从缓存绘制指针，避免每帧重绘
        if (this._pointerCanvas) {
            this.ctx.drawImage(this._pointerCanvas, 0, 0);
        }
    }

    spin() {
        if (this.isSpinning || this.options.length === 0) return;
        this.isSpinning = true;

        const targetRotation = Math.random() * Math.PI * 2 + Math.PI * 6;
        const duration = 4000 + Math.random() * 1000;
        const startTime = Date.now();
        const startRotation = this.rotation;

        const animate = () => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);

            this.rotation = startRotation + targetRotation * eased;
            this.draw();

            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                this.isSpinning = false;
                const result = this.getResult();
                if (this.onResult) this.onResult(result);
            }
        };

        requestAnimationFrame(animate);
    }

    getResult() {
        const { options, weights, rotation } = this;
        const totalWeight = weights.reduce((a, b) => a + b, 0);
        const normalizedRotation = ((rotation % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
        
        // 指针在顶部（12点钟方向）
        let pointerAngle = (2 * Math.PI - normalizedRotation) % (2 * Math.PI);
        if (pointerAngle < 0) pointerAngle += 2 * Math.PI;

        let currentAngle = 0;
        for (let i = 0; i < options.length; i++) {
            const sliceAngle = (weights[i] / totalWeight) * 2 * Math.PI;
            if (pointerAngle >= currentAngle && pointerAngle < currentAngle + sliceAngle) {
                return { option: options[i], index: i };
            }
            currentAngle += sliceAngle;
        }

        return { option: options[0], index: 0 };
    }

    setOptions(options, weights = null) {
        this.options = options;
        this.weights = this._normalizeWeights(weights || options.map(() => 1), options.length);
        this.rotation = 0;
        this.draw();
    }
}
